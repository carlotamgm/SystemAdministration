#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

echo -n "Introduzca una tecla: "
read tecla

case $tecla in
	[a-zA-Z]* )
		echo "$tecla es una letra" ;;
	[0-9]* )
		echo "$tecla es un numero" ;;
	* )
		echo "$tecla es un caracter especial" ;;
esac