#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

IFS=$'\n'		# para coger nombres de directorios con espacios en ellos

echo -n "Introduzca el nombre de un directorio: "
read ruta

# comprobamos la existencia del directorio
if test -d "$ruta" &> /dev/null
then
	numDirs=$(ls -l $ruta | grep ^d | wc -l)
	numFiles=$(ls -l $ruta | grep ^- | wc -l)
	echo  "El numero de ficheros y directorios en $ruta es de $numFiles y $numDirs, respectivamente"
else
	echo "$ruta no es un directorio"
fi