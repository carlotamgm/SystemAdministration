#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

dir=$(stat -c %n,%Y ~/bin??? 2> /dev/null |sort -t ',' -k 2n | cut -d ',' -f1 | cut -d $'\n' -f1 )
if test "$dir" = ""
then
	dir=$(mktemp -d $HOME/binXXX)
	echo "Se ha creado el directorio $dir"
fi

echo "Directorio destino de copia: $dir"

numCopias=0

# copiamos todos los ejecutables al directorio temporal
for fich in *
do
	# comprobamos si es un fichero ejecutable
    if test -x "$fich" -a -f "$fich"
    then
        cp "$fich" "$dir"
	echo "./$fich ha sido copiado a $dir"
        numCopias=$(($numCopias+1))
    fi
done

# comprobamos cuantos ejecutables se han copiado
if test $numCopias -eq 0
then 
	echo "No se ha copiado ningun archivo"
else
	echo "Se han copiado $numCopias archivos"
fi
