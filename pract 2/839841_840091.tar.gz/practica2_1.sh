#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

IFS=$'\n'		# para coger nombres de ficheros con espacios en ellos

echo -n "Introduzca el nombre del fichero: "
read nomFich

# comprobamos la existencia del fichero
if ! ls $nomFich &> /dev/null
then
	echo "$nomFich no existe"
else
	echo -n "Los permisos del archivo $nomFich son: "
	# comprobamos permisos de lectura
	if test -r $nomFich
	then
		echo -n r
	else
		echo -n -
	fi
	# comprobamos permisos de escritura
	if test -w $nomFich
	then
		echo -n w
	else
		echo -n -
	fi
	# comprobamos permisos de ejecucion
	if test -x $nomFich
	then
		echo x
	else
		echo -
	fi
fi
