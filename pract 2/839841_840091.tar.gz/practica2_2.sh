#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

for fich in "$@"
do
	# comprobamos la existencia del fichero
	if test -f "$fich" &> /dev/null
	then
		more "$fich"
	else
		echo "$fich no es un fichero"
	fi
done