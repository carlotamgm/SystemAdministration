#!/bin/bash
#839841, Moncasi Gosá, Carlota, M, 3, B
#840091, Naranjo Ventura, Elizabeth Lilai, M, 3, B

# comprobamos el número de parámetros
if test $# -ne 1
then
	echo "Sintaxis: practica2_3.sh <nombre_archivo>"
else
	# comprobamos la existencia del fichero
	if test -f "$1"
	then
		chmod ug+x "$1"
		stat -c '%A' "$1"
	else
		echo "$1 no existe"
	fi
fi